import{a as e}from"./index-541256d7.js";const r=()=>e("div",{children:"Feedbacks"});export{r as default};
//# sourceMappingURL=Feedbacks-64406df1.js.map
