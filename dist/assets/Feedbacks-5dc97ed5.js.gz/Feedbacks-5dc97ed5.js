import{a as e}from"./index-459f2791.js";const r=()=>e("div",{children:"Feedbacks"});export{r as default};
//# sourceMappingURL=Feedbacks-5dc97ed5.js.map
