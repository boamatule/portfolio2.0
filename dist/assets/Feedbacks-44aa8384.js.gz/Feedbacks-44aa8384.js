import{a as e}from"./index-b0c9de15.js";const r=()=>e("div",{children:"Feedbacks"});export{r as default};
//# sourceMappingURL=Feedbacks-44aa8384.js.map
