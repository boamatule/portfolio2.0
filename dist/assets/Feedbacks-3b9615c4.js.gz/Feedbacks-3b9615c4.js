import{a as e}from"./index-22e0b2bd.js";const r=()=>e("div",{children:"Feedbacks"});export{r as default};
//# sourceMappingURL=Feedbacks-3b9615c4.js.map
