import{a as e}from"./index-a330bde9.js";const r=()=>e("div",{children:"Feedbacks"});export{r as default};
//# sourceMappingURL=Feedbacks-372f4031.js.map
